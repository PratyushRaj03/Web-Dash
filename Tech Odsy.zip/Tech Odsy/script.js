document.addEventListener('DOMContentLoaded', () => {
    const productItems = document.querySelectorAll('.content > div');
    const imageDescription = document.createElement('div');
    imageDescription.classList.add('image-description');
    if (imageDescription) {
        imageDescription.style.display = 'none';
    }
    document.body.appendChild(imageDescription);

    productItems.forEach(item => {
        const img = item.querySelector('img');
        const description = item.querySelector('p').cloneNode(true);

        item.addEventListener('click', () => {
            imageDescription.innerHTML = '';
            const imgClone = img.cloneNode(true);
            imageDescription.appendChild(imgClone);
            imageDescription.appendChild(description);
            imageDescription.style.display = 'flex';
            document.body.classList.add('blur');
        });
    });

    window.addEventListener('click', (e) => {
        if (e.target === imageDescription) {
            imageDescription.style.display = 'none';
            document.body.classList.remove('blur');
        }
    });

    window.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && imageDescription.style.display === 'flex') {
            imageDescription.style.display = 'none';
            document.body.classList.remove('blur');
        }
    });
});

const bookingForm = document.getElementById('bookingForm');

bookingForm.addEventListener('submit', (event) => {
  event.preventDefault(); // Prevent the form from submitting and reloading the page

  const tourSelect = document.getElementById('tourSelect');
  const dateInput = document.getElementById('dateInput');
  const personInput = document.getElementById('personInput');
  const emailInput = document.getElementById('emailInput');

  const tour = tourSelect.value;
  const date = dateInput.value;
  const persons = personInput.value;
  const email = emailInput.value;

  // Perform booking logic here
  // You can send the data to a server or display a confirmation message
  console.log(`Tour: ${tour}, Date: ${date}, Persons: ${persons}, Email: ${email}`);

  // Reset the form after submission
  bookingForm.reset();
});